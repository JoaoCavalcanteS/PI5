import React from "react";

const AvisosAlertas = () => {
  return (
    <div>
      <h1>alerta</h1>
    </div>
  );
};

export default AvisosAlertas;
