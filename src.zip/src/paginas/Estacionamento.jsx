import React from "react";

const Estacionamento = () => {
  return (
    <div>
      <h1>estacionamento</h1>
    </div>
  );
};

export default Estacionamento;
