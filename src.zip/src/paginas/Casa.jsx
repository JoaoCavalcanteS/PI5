import React from "react";

const Casa = () => {
  return (
    <div>
      <h1>casa</h1>
    </div>
  );
};

export default Casa;
