import React from "react";

const SalaoDeFestas = () => {
  return (
    <div>
      <h1>SalaoDeFestas</h1>
    </div>
  );
};

export default SalaoDeFestas;
