import React from "react";

const PrimeiroAcesso = () => {
  return (
    <div>
      <h1>PrimeiroAcesso</h1>
    </div>
  );
};

export default PrimeiroAcesso;
