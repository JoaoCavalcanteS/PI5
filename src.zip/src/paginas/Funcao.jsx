import React from "react";

const Funcao = ()=>{
  return(
    <div>
        <h1>Hello</h1>
    </div>
  );
};

export default Funcao;