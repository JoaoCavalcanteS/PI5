import React from "react";

const PaginaInicial = () => {
  return (
    <div>
      <h1>pag PaginaInicial</h1>
    </div>
  );
};

export default PaginaInicial;
